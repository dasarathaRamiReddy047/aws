package com.epayRoll;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EpayRollApplication {

	public static void main(String[] args) {
		SpringApplication.run(EpayRollApplication.class, args);
	}

}
